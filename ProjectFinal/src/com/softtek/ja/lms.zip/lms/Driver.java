package com.softtek.ja.lms;

public class Driver 
{
	public static void main(String[] args) 
	{
		LoginPage l1=new LoginPage();
		l1.login();
	}
}
